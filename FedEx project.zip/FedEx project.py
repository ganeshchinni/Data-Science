# -*- coding: utf-8 -*-
"""
Created on Sun Nov 14 12:05:27 2021

@author: chinni
"""

import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.impute import SimpleImputer
from sklearn.neighbors import KNeighborsClassifier
import matplotlib.pyplot as plt

fedEx=pd.read_csv(r"C:\data\data science\Study material\Project FedEx\FedEx\fedex.csv")
fedEx.shape##checking shape of dataset
fedEx.dtypes

#dropping non-numeric columns
fedEx.drop('Carrier_Name', axis=1, inplace=True)
fedEx.drop('Source', axis=1, inplace=True)
fedEx.drop('Destination', axis=1, inplace=True)


##creating a function to convert a value into hours and min. formaate

def convert(num):
    hours = num // 100
    mins = num %100
    total = (hours *60) + mins
    return total

##converting given time into hours and min. formate

fedEx['Actual_Shipment_Time']=fedEx['Actual_Shipment_Time'].apply(convert)

fedEx['Planned_Shipment_Time']=fedEx['Planned_Shipment_Time'].apply(convert)

fedEx['Planned_Delivery_Time']=fedEx['Planned_Delivery_Time'].apply(convert)

fedEx.isna().sum()## checking na cells in the dataset
from sklearn.impute import SimpleImputer
imputer = SimpleImputer(missing_values = np.nan,strategy ='mean')
imputer = imputer.fit(fedEx)
fedEx = imputer.transform(fedEx)
fedEx.shape## checking shape of new dataset

X = fedEx[:, :-1]
Y = fedEx[:, -1]

for i in range(len(Y)):
    if Y[i] > 0.5:
        Y[i]=0
    else:
        Y[i]=1

xtrain, xtest, ytrain, ytest = train_test_split( X, Y, test_size = 0.3, random_state = 1 )

error = []
start = 5
stop = 15

for i in range(start, stop):
    knn = KNeighborsClassifier(n_neighbors=i)
    knn.fit(xtrain, ytrain)
    pred_i = knn.predict(xtest)
    error.append(np.mean(pred_i != ytest))
    
plt.figure(figsize=(12, 6))
plt.plot(range(start, stop), error, color='red', linestyle='dashed', marker='o',
         markerfacecolor='blue', markersize=10)

plt.title('Error Rate K Value')
plt.xlabel('K Value')
plt.ylabel('Mean Error')
plt.show()

